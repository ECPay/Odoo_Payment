##
要測試 Payment, 要先設定以下方式:
1. 環境設定為 Test
2. 介接設定
    a. 特店編號 = 2000132
    b. 介接 HashKey = 5294y06JbISpM5x9
    c. 介接 HashIV = v77hoKGq4kWxNNIS
3. command line 下:
`ngrok http 8069` 之後, 設定網域名稱
4. 付款時, 測試的信用卡號為 4311-9522-2222-2222